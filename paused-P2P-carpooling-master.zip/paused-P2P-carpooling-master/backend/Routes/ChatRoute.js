import express from "express"

const router = express.Router()

router.post("/",createChat)

export default router;